within B01_2_HeatExchanger_Pipes;
package XX
  extends Modelica.Icons.Package;
  
end XX;
