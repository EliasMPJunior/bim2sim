package B01_2_HeatExchanger_Pipes
  extends Modelica.Icons.Package;
  
  annotation (uses(
    Modelica(version="4.0.0"),    AixLib(version="2.1.1")),    version="1");
end B01_2_HeatExchanger_Pipes;
